<?php

$lang['Please_Enter_Phone_Number']='Please Enter Phone Number'; 

$lang['Phone_Number_Should_be_10_Digit_Number']='Phone Number Should be 10 Digit Number'; 

$lang['We_Have_Sent_Verification_Code_to_Your_Mobile_Please_Enter_Verification_Code']='We Have Sent Verification Code to Your Mobile Please Enter Verification Code'; 

$lang['We_sent_a_verification_code_to']='We sent a verification code to'; 

$lang['Verification_Code_Does_not_match_Please_enter_Correct_Code']='Verification Code Does not match Please enter Correct Code'; 

$lang['Your_current_phone_number_is_verfied_actually_Are_you_sure_you_want_to_change_it?']='Your current phone number is verfied actually, Are you sure,you want to change it?'; 

$lang['sorry_Enable_to_change']='sorry.Enable to change.'; 

$lang['new_phone_number_cancelled']='new phone number cancelled'; 

$lang['Please_enter_your_old_password']='Please enter your old password'; 

$lang['Please_enter_your_new_passowrd']='Please enter your new passowrd'; 

$lang['Re_enter_the_new_password']='Re-enter the new password'; 

$lang['Passwords_do_not_match']='Passwords do not match'; 

$lang['Please_Select_Country']='Please Select Country'; 

$lang['Please_Proceed_after_Verifing_Your_Id']='Please Proceed after Verifing Your Id'; 

$lang['Amount_Not_in_zero']='Amount Not in zero'; 

$lang['Plan_Information']='Plan Information'; 

$lang['Now_you_are_active_in']='Now you are active in'; 

$lang['Price']='Price'; 

$lang['Valid_until(Month)']='Valid until(Month)'; 

$lang['Purchase_Date']='Purchase Date'; 

$lang['Expiry_Date']='Expiry Date'; 

$lang['Now_you_are_active_in_free_plan']='Now you are active in free plan'; 

$lang['Buy_a_new_plan']='Buy a new plan'; 

$lang['your_rate_has_been_saved']='your rate has been saved'; 

$lang['please_retry']='please retry'; 

$lang['Order_Id']='Order Id'; 

$lang['Sub_Total']='Sub Total'; 

$lang['Order_Date']='Order_Date'; 

$lang['Shipping']='Shipping'; 

$lang['Discount']='Discount'; 

$lang['Tax']='Tax'; 

$lang['Grand_Total']='Grand Total'; 

$lang['Product_Image']='Product Image'; 

$lang['Product_Name']='Product Name'; 

$lang['Qty']='Qty'; 

$lang['Unit_Price']='Unit Price'; 

$lang['Received_Status']='Received Status'; 

$lang['Comments']='Comments'; 

$lang['No_comments_available']='No comments available'; 

$lang['Reviews_not_available']='Reviews not available'; 

$lang['Product_details_not_available']='Product details not available'; 

$lang['Loading']='Loading'; 

$lang['Rank']='Rank'; 

$lang['Your rank is a real-time popularity score of the things you ve added to']='Your rank is a real-time popularity score of the things you ve added to'; 

$lang['The more popular your things, the higher your rank']='The more popular your things, the higher your rank'; 

$lang['Followers']='Followers'; 

$lang['Following']='Following'; 

$lang['Follow']='Follow'; 

$lang['RSS_Feed']='RSS Feed'; 

$lang['Share_Profile']='Share Profile'; 

$lang['Recent_Activity']='Recent Activity'; 

$lang['Jump_to_top']='Jump to top'; 

$lang['by']='by'; 

$lang['Edit Inquiry Details']='Edit Inquiry Details'; 

$lang['Rental_Name']='Rental Name'; 

$lang['Arrival_Date']='Arrival Date'; 

$lang['Depature_Date']='Depature Date'; 

$lang['Please_enter_some_message_to_send']='Please enter some message to send'; 

$lang['No verifications yet,To get verify']='No verifications yet,To get verify'; 

$lang['Phone_Number_Should_be_Valid']='Phone Number Should be Valid'; 

$lang['Message_is_required!']='Message is required!'; 

$lang['Select_approval!']='Select approval!'; 

$lang['Invites_you_to_join_on']='Invites you to join on'; 

$lang['How_it_Works']='How it Works'; 

$lang['Rent unique, local accommodations on any budget, anywhere in the world']='Rent unique, local accommodations on any budget, anywhere in the world'; 

$lang['Explore']='Explore'; 

$lang['Find_the_perfect_place']='Find the perfect place'; 

$lang['Message_hosts']='Message hosts'; 

$lang['Book']='Book'; 

$lang['View_your_itinerary']='View your itinerary'; 

$lang['Booking']='Booking'; 

$lang['Amount_to_be_paid']='Amount to be paid'; 

$lang['Adults']='Adults'; 

$lang['Children']='Children'; 

$lang['No_rentals_found']='No rentals found'; 

$lang['Edit_Wish_List']='Edit Wish List'; 

$lang['Please_enter_wishlist_category']='Please enter wishlist category'; 

$lang['This_category_already_exists']='This category already exists'; 

$lang['Mobile_Starred_Listings']='Mobile Starred Listings'; 

$lang['Edit']='Edit'; 

$lang['Yours_Wishlist_is_Empty']='Yours Wishlist is Empty'; 

$lang['Bed_rooms']='Bed rooms'; 

$lang['Bath_Rooms']='Bath Rooms'; 

$lang['change']='change'; 

$lang['Remove']='Remove'; 

$lang['Everyone']='Everyone'; 

$lang['Only_Me']='Only Me'; 

$lang['Popular']='Popular'; 

$lang['Referrals']='Referrals'; 

$lang['Email_Id_already_exist']='Email Id already exist'; 

$lang['Does_not_Support_Rep_Code']='Does not Support Rep Code'; 

$lang['OR']='OR'; 

$lang['English']='English'; 

$lang['Preview']='Preview'; 

$lang['StumbleUpon']='StumbleUpon'; 

$lang['Tumblr']='Tumblr'; 

$lang['BKohtakte']='BKohtakte'; 

$lang['OnHOKnaccHNKN']='OnHOKnaccHNKN'; 

$lang['mixi']='mixi'; 

$lang['q-zone']='q-zone'; 

$lang['Weibo']='Weibo'; 

$lang['Renren']='Renren'; 

$lang['Open this window again and this message will still be here']='Open this window again and this message will still be here'; 

$lang['Use_Wallet']='Use Wallet'; 

$lang['Apt, Suite, Bldg (optional)']='Apt, Suite, Bldg (optional)'; 

$lang['Please_wait_your_transaction_on_process']='Please wait your transaction on process'; 

$lang['Great Choice! You are Just 1 minute away from booking']='Great Choice! You are Just 1 minute away from booking'; 

$lang['Fill_details']='Fill in your details below to complete the booking. Once you submit your booking, it will be confirmed immediately and you will receive an email with the host’s contact details and the exact address of the property'; 

$lang['See_all']='See all'; 

$lang['Under_development']='Under development'; 

$lang['This_field_is_required']='This field is required'; 

$lang['You_have_no_permission']='You have no permission'; 

$lang['Minimum_Stay_Shoud_be']='Minimum Stay Shoud be'; 

$lang['Days']='Days'; 

$lang['Host_is_removed']='Host is removed so booking is not available'; 

$lang['Maximum_number_of_guests_is']='Maximum number of guests is'; 

$lang['Language_and_Currency']='Language and Currency'; 

$lang['London']='London'; 

$lang['Default_Cedis']='Default Cedis'; 

$lang['Wish_list']='Wish list'; 

$lang['please_Choose_Wishlist_Name']='please Choose Wishlist Name'; 

$lang['What_kind_of_neighborhood_are_you_looking_for']='What kind of neighborhood are you looking for'; 

$lang['All']='All'; 

$lang['See_places_to_stay']='See places to stay'; 

$lang['The_community_says']='The community says'; 

$lang['see_all_neighborhoods']='See listings in all saved neighborhoods'; 

$lang['New_Yorkers']='New Yorkers get around primarily via the subway and taxi system. New York s subway system is one of the best in the world and you can get virtually anywhere in the city for a flat fee of $2.50 24 hours a day. Taxis are readily available across central and downtown Manhattan and conveniently, they take credit cards. Driving your own car is only possible in the outer neighborhoods unless you want to spend a fortune on parking and pass many hours sitting in traffic'; 

$lang['See']='See'; 

$lang['listings']='listings'; 

$lang['Known_for']='Known for'; 

$lang['Locals_Love']='Locals Love'; 

$lang['Bank holidays, free museums, the footy, street markets, smart sarcasm, Sunday roasts, real ale pubs, pop-ups, curry, tea and cake, the NHS, minding the gap']='Bank holidays, free museums, the footy, street markets, smart sarcasm, Sunday roasts, real ale pubs, pop-ups, curry, tea and cake, the NHS, minding the gap'; 

$lang['Locals_Complain_About']='Locals Complain About'; 

$lang['The weather, highrents, rising tube fares, queues, commute times, slow walkers, the NHS, politiciansand bankers, people who stand on the left']='The weather, highrents, rising tube fares, queues, commute times, slow walkers, the NHS, politiciansand bankers, people who stand on the left'; 

$lang['neighborhoods. Which are right for you']='neighborhoods. Which are right for you'; 

$lang['More neighborhoods']='More neighborhoods'; 

$lang['Download_complete']='Download complete'; 

$lang['Please_enter_confirm_password']='Please enter confirm password'; 

$lang['Passwords_not_matching']='Passwords not matching'; 

$lang['Please_enter_the_email_address']='Please enter the email address'; 

$lang['Please_enter']='Please enter the password'; 

$lang['Password must be minimum of 6 characters']='Password must be minimum of 6 characters'; 

$lang['Please_enter_the_first_name']='Please enter the first name'; 

$lang['Please_enter_the_last_name']='Please enter the last name'; 

$lang['Enter_valid_captcha']='Enter valid captcha'; 

$lang['Bank_full_name_required']='Bank full name required'; 

$lang['Bank_number_required']='Bank number required'; 

$lang['Bank_code_required']='Bank code required'; 

$lang['Email_id_required']='Email id required'; 

$lang['Enter_new_password']='Enter new password'; 

$lang['Confirm password required']='Confirm password required'; 

$lang['Passwords doesnot match']='Passwords doesnot match'; 

$lang['Your comment is empty']='Your comment is empty'; 

$lang['Are_you_sure']='Are you sure'; 

$lang['Please Enter the Location']='Please Enter the Location'; 

$lang['Please Enter the County']='Please Enter the County'; 

$lang['Please Enter the State']='Please Enter the State'; 

$lang['Please Enter the City']='Please Enter the City'; 

$lang['e.g.']='e.g.'; 

$lang['Credit Card']='Credit Card'; 

$lang['JCB']='JCB'; 

$lang['After clicking ']='After clicking '; 

$lang['Neighborhood overview']='Neighborhood overview'; 

$lang['What do you love about your neighborhood']='What do you love about your neighborhood'; 

$lang['What do you think your guests should experience']='What do you think your guests should experience'; 

$lang['Getting around']='Getting around'; 

$lang['Is there convenient public transit']='Is there convenient public transit'; 

$lang['Is parking included with your listing or nearby']='Is parking included with your listing or nearby'; 

$lang['How does your guest get to your listing from the airport']='How does your guest get to your listing from the airport'; 

$lang['Other Things to Note']='Other Things to Note'; 

$lang['Are there any other details you d like to share']='Are there any other details you d like to share'; 

$lang['House Rules']='House Rules'; 

$lang['How do you expect your guests to behave']='How do you expect your guests to behave'; 

$lang['Do you allow pets']='Do you allow pets'; 

$lang['Do you have rules against smoking']='Do you have rules against smoking'; 

$lang['Will you be present at the listing during your guest s stay']='Will you be present at the listing during your guest s stay'; 

$lang['to']='to'; 

$lang['Start Date']='Start Date'; 

$lang['End Date']='End Date'; 

$lang['Term of service should be acceptable']='Term of service should be acceptable'; 

$lang['Please wait your transaction on process']='Please wait your transaction on process'; 

$lang['Sorry! please check']='Sorry! please check'; 

$lang['Verify via sms']='Verify via sms'; 

$lang['Please select currency code']='Please select currency code'; 

$lang['Business Travel']='Business Travel'; 

$lang['Please Enter City']='Please Enter City'; 

$lang['Where do you want to go']='Where do you want to go'; 

$lang['Your Name']='Your Name'; 

$lang['Full name required']='Full name required'; 

$lang['Email required']='Email required'; 

$lang['Subject required']='Subject required'; 

$lang['Message required']='Message required'; 

$lang['Your@yourcompany.com']='Your@yourcompany.com'; 

$lang['General Enquiry']='General Enquiry'; 

$lang['Please Enter Message']='Please Enter Message'; 

$lang['Any questions about being a guest, check out our']='Any questions about being a guest, check out our'; 

$lang['FAQs']='FAQs'; 

$lang['or']='or'; 

$lang['drop us a line']='drop us a line'; 

$lang['Start Booking Today']='Start Booking Today'; 

$lang['List Your Space']='List Your Space'; 

$lang['Start earning money today']='Start earning money today'; 

$lang['Please Enter the Correct ZipCode']='Please Enter the Correct ZipCode'; 

$lang['Type the text']='Type the text'; 

$lang['Select the Membership']='Select the Membership'; 

$lang['Edit Profile Image']='Edit Profile Image'; 

$lang['Enter message']='Enter message'; 

$lang['Sorry, the list was unavailable right moment']='Sorry, the list was unavailable right moment'; 

$lang['ocean side, transit, relaxing']='ocean side, transit, relaxing'; 

$lang['Trip']='Trip'; 

$lang['Visible only to you and not shared anywhere']='Visible only to you and not shared anywhere'; 

$lang['Prev']='Prev'; 

$lang['Refresh']='Refresh'; 

$lang['captcha']='captcha'; 

$lang['dd-mm-yyyy']='dd-mm-yyyy'; 

$lang['Wallet']='Wallet'; 

$lang['Cancellation Policy']='Cancellation Policy'; 

$lang['Past_Dispute']='Past Dispute'; 

$lang['Need_more_info_about']='Need more info about'; 

$lang['general_experience']='If you have general questions about how experiences work'; 

$lang['visit_our_FAQ']='visit our FAQ'; 

$lang['Send_Message']='Send Message'; 

$lang['Make_sure_to_introduce_yourself']='Make sure to introduce yourself'; 

$lang['When_do_you_want_to_go']='When do you want to go?'; 

$lang['trycontacthost']='If you can’t find the dates you want, try contacting the host'; 

$lang['perperson']='per person'; 

$lang['for_you']='FOR YOU'; 

$lang['homes']='HOMES'; 

$lang['err_price_per_night']='Please enter price per night'; 

$lang['saved']='Saved'; 

$lang['err_enter_title']='Please Enter Title'; 

$lang['err_enter_summary']='Please Enter Summary'; 

$lang['request_to_book']='Request to Book'; 

$lang['instant_pay']='Instant Pay'; 

$lang['charecters_only']='Characters Only'; 

$lang['err_summary']='You can not type more than 150 words'; 

$lang['err_choose_yes']='Please Choose Yes'; 

$lang['somemore_details']='Add some more details!'; 

$lang['guest_access']='Guest access'; 

$lang['interaction_with_guest']='Interaction with guest'; 

$lang['neighborhood']='Neighborhood'; 

$lang['err_image_height']='Image Height and Width should have 700 * 460 px or Above'; 

$lang['err_check_atleast_one']='Please check atleast one amenities'; 

$lang['your_location']='Your Location'; 

$lang['charecters_and_numbers_only']='Characters and Numbers Only'; 

$lang['digit_only']='Digit Only'; 

$lang['Location']='Location'; 

$lang['available_coupons']='Available Coupons'; 

$lang['S.no']='S.no'; 

$lang['coupon_name']='Coupon Name'; 

$lang['coupon_code']='Coupon Code'; 

$lang['prodcut_list']='Prodcut List'; 

$lang['from']='From'; 

$lang['limit_count']='Limit Count'; 

$lang['kindly_make_payment']='Kindly make a payment and contact Host through this conversation.'; 

$lang['no_upcoming_reservations']='You have no upcoming reservations.'; 

$lang['no_past_reservations']='You have no past reservations.'; 

$lang['no_name']='No Name'; 

$lang['not_specified']='Not Specified'; 

$lang['none_selected']='None Selected'; 

$lang['paid']='Paid'; 

$lang['approval_pending']='Approval Pending'; 

$lang['booking_no']='Booking No'; 

$lang['enter_living_place']='Enter your living place here'; 

$lang['write_something_about_ourself']='Write something about yourself'; 

$lang['where_did_your_schooling']='Where did your schooling'; 

$lang['your_working_place']='Your working place'; 

$lang['err_user_profile_picture']='Image Should be JPEG,JPG,PNG and below 272*272px'; 

$lang['upload_your_documents']='Upload your Documents'; 

$lang['goverment_id']='Goverment Id'; 

$lang['upload_proof']='Upload the picture of your official id such as Passport or Voter ID'; 

$lang['passport']='Passport'; 

$lang['voter_id']='Voter ID'; 

$lang['driving_licence']='Driving Licence'; 

$lang['note']='Note'; 

$lang['err_upload_proof']='Please upload jpg,gif,png or pdf,doc file to verification, File size limit it 2 mb'; 

$lang['once_you_uploaded']='Once You Upload Proof you cannot able to edit Until Admin Gives Acceptance'; 

$lang['proof_name']='Proof Name'; 

$lang['file']='File'; 

$lang['upload_new_proof']='Are You Want to upload a new proof?'; 

$lang['request_sent']='Request Sent'; 

$lang['request_to_verify']='Request to Verify'; 

$lang['proof_not_found!']='Proof not found!'; 

$lang['choose_another_proof']='Please choose another proof type.'; 

$lang['rewrite_existing_one']='Proof for this type is already submitted. Do you want rewrite the existing one?'; 

$lang['choose_file']='Please Choose File'; 

$lang['request_to_admin']='Are you sure want to send request to admin?'; 

$lang['succ_message_proof']='Id proof successfully submitted for verification.'; 

$lang['no_past_reviews']='No past reviews found!'; 

$lang['no_reviews_by_you']='No reviews posted by you!'; 

$lang['cancel_booking']='Cancel booking'; 

$lang['reject']='Reject'; 

$lang['no_dispute_about_you']='No dispute about you!'; 

$lang['dispute_accepted']='Dispute Accepted'; 

$lang['dispute_failed']='Accept on dispute failed'; 

$lang['dispute_rejected']='Dispute Rejected'; 

$lang['dispute_reject_failed']='Reject on dispute failed'; 

$lang['rejected']='Rejected'; 

$lang['anything_to_cancel']='You did not book anything to cancel!'; 

$lang['cancel_booking_accepted']='Cancel booking accepted'; 

$lang['cancel_booking_failed']='Accept on cancel booking failed'; 

$lang['cancelation_is_rejected']='Cancellation is rejected'; 

$lang['cancelation_is_rejected_failed']='Reject on cancellation failed'; 

$lang['mail_send_success']='Mail Send Success'; 

$lang['previous']='Previous'; 

$lang['mobile_notfification']='Mobile Notification Saved Successfully..!'; 

$lang['your_wallet']='Your Wallet'; 

$lang['numbers_only']='Numbers Only'; 

$lang['enter_account_name']='Please enter the account name!'; 

$lang['enter_account_number']='Please enter the account number!'; 

$lang['enter_bank_name']='Please enter the bank name!'; 

$lang['account_name_here']='Account name here'; 

$lang['account_number_here']='Account number here'; 

$lang['enter_bank_name_here']='Enter bank name here'; 

$lang['enter_paypal_email_here']='Enter Paypal email here'; 

$lang['pasword_length']='Password Should be atleast 6'; 

$lang['want_to_cancel']='Are You Sure Want to cancel your Account.?'; 

$lang['user']='User'; 

$lang['total_wallet_amount']='Total Wallet Amount'; 

$lang['used_from_wallet']='Used from Wallet'; 

$lang['balance_in_wallet']='Balance in Wallet'; 

$lang['wallet_empty_message']='Your wallet Empty. Use invite friends for credit your wallet.'; 

$lang['back_January']='January'; 

$lang['back_February']='February'; 

$lang['back_March']='March'; 

$lang['back_April']='April'; 

$lang['back_May']='May'; 

$lang['back_June']='June'; 

$lang['back_July']='July'; 

$lang['back_August']='August'; 

$lang['back_September']='September'; 

$lang['back_October']='October'; 

$lang['back_November']='November'; 

$lang['back_December']='December'; 

$lang['verified_host']='Verified Host'; 

$lang['verified_proof']='Verified Proof'; 

$lang['unVerified_proof']='UnVerified Proof'; 

$lang['experience']='EXPERIENCE'; 

$lang['Become_Host']='Become a Host'; 

$lang['create_experience']='Create Experience'; 

$lang['immersions']='Immersions'; 

$lang['happen_over_days']='Happen over multiple days'; 

$lang['experiences']='Experiences'; 

$lang['last_two_hours']='Last 2 or more hours'; 

$lang['category']='Category'; 

$lang['no_experience']='No Experience'; 

$lang['err_valid_price']='Please enter valid price'; 

$lang['save_mobile_settings']='Save Mobile Settings'; 

$lang['no_dispute_byyou']='No dispute by you!'; 

$lang['YourExperiences']='Your Experiences'; 

$lang['NewExperience']='Add New Experience'; 

$lang['ManageExperiences']='Manage Experiences'; 

$lang['my_experience']='My Experiences'; 

$lang['PreviousExperiences']='Previous Experiences'; 

$lang['ExperiencesReservation']='My Experiences Reservations'; 

$lang['TransactionHistory']='Transaction History'; 

$lang['My_Messages']='My Messages'; 

$lang['YourExpeirence']='My Experience'; 

$lang['submit_dispute']='Submit Dispute'; 

$lang['no_upcoming_reservations_exp']='You have no upcoming reservations.'; 

$lang['Createanewexperience']='Create a new experience.'; 

$lang['via_bank']='Via Bank'; 

$lang['list_Basics']='Basics'; 

$lang['experience_language_details']='Language'; 

$lang['experience_organization_details']='Organization'; 

$lang['experience_details']='Switch to your Language'; 

$lang['experience_title_new']='Title Your Experience'; 

$lang['schedule_experience']='Timing'; 

$lang['Aexperiencetitleandsummary_new']='A title and summary displayed on your public experience page.'; 

$lang['tagline_experience']='Tagline'; 

$lang['exp_example']='Example'; 

$lang['experience_det']='Name your Experience'; 

$lang['exp_great_summary_new']='A title plays an important role. The main purpose of a title is to garner attention and entice people to book your experience. Try to include name of the location if it’s a defining part of the experience.'; 

$lang['what_we_do']='What we will do'; 

$lang['where_we_will_be']='Where we will be'; 

$lang['where_wil_meet']='Where we will meet'; 

$lang['what_you_will_provide']='What you will provide'; 

$lang['notes_to_guest']='Notes'; 

$lang['about_exp_host']='About you'; 

$lang['guest_requirement']='Guest Requirements'; 

$lang['group_size']='Group size'; 

$lang['exp_set_basic_fields']='Set the basic mandatory fields of your experience.'; 

$lang['exp_fill_all_fields']='Please fill all mandatory fields'; 

$lang['Save_and_Continue']='Save & Continue'; 

$lang['exp_basic_experience']='Speak out your Experience'; 

$lang['exp_fill_your_basic_info']='No one can epitomize your experience better than you. Depict your unique experience in a short and sweet way. The description should outline all the stellar features of Your Experience in 250 Characters or Less.'; 

$lang['exp_you_cant_edit']='Create your experience earn extra money by attracting more explorers. No matter who you are, you can be a chef, hiker, theater artist, or a singer who love to share their experience with others. Anyone can create and host their interest or passion.'; 

$lang['exprience_type']='Experience Type'; 

$lang['total_hours']='Total Hours'; 

$lang['experience_category']='Experience Category'; 

$lang['exp_which_language']='Which Language will you host in?'; 

$lang['Aexperiencetitleandsummary']='You will write your descriptions in this language and guests will expect you to speak it during experiences.'; 

$lang['exp_submission_language']='Submission Language'; 

$lang['exp_great_summary']='“A new language is a new life”. Are you flexible in more than one language? Please specify it. Make your guest comfort with their native language. With languages you can make your guest to feel they are at Home. Don’t miss out any of your guest.'; 

$lang['exp_adddtionals']='Adddtionals'; 

$lang['exp_additionally']='Additionally have to mention the special features included in your experience like languages support, the things provided by guide on the time of experience.'; 

$lang['exp_please_choose_one']='Please choose atleast one language'; 

$lang['exp_tell_us_about']='Tell us about the organization you represent'; 

$lang['exp_organization_name']='Organization name'; 

$lang['exp_characters_remaining']='characters remaining'; 

$lang['exp_about_your_organization']='About your Organization'; 

$lang['exp_skip']='Skip'; 

$lang['exp_organization_details']='Is this a social impact experience?'; 

$lang['exp_great_summary_exe']='If you’re partnering with a nonprofit or a charitable organization, you can host a social impact experience. Make others aware about social issues. Always try to provide right information about your organization'; 

$lang['exp_basic']='Basic'; 

$lang['exp_title']='Experience Title'; 

$lang['exp_add_new']='Add new'; 

$lang['experience_Schedule']='New Schedule'; 

$lang['exp_from_date']='From Date'; 

$lang['exp_to_date']='To Date'; 

$lang['exp_choose_date']='Choose date'; 

$lang['exp_start_time']='Start Time'; 

$lang['exp_end_time']='End Time'; 

$lang['exp_no_activity_found']='No Activity Found..'; 

$lang['exp_time_schedule_succ']='Time schedule is updated successfully'; 

$lang['exp_are_you_sure_todelete']='Are you sure to delete this scheduled timing?'; 

$lang['exp_time_removed_succ']='Time schedule has been removed successfully'; 

$lang['exp_time_schedule_added']='Time schedule has been added successfully'; 

$lang['exp_experience_schedule']='Experience Schedule'; 

$lang['exp_schedule_for_newdate']='Experience Schedule is for add new dates for the exloring the experience and also manage the dates. You can add multiple dates for each experience. Once the experience is booked or experience expried, you cann not edit it.'; 

$lang['exp_for_dates_youhave']='For Dates you have to add time schedule, schedule title is important for identify each timing session activity. You can explain the follow for that session in description.'; 

$lang['exp_invalid_schedule_periods']='Invalid Schedule Periods.'; 

$lang['exp_schedule_period_saved']='Schedule Period saved successfully.'; 

$lang['exp_schedule_date_req']='schedule date required.'; 

$lang['exp_title_req']='title is required'; 

$lang['exp_fill_all']='Please fill all fields'; 

$lang['exp_set_your_time']='Schedule your Experience'; 

$lang['exp_frame_schedule']='Frame your Schedule'; 

$lang['exp_schedule_for_newdate_new']='It s all about a matter of time. Organize your experience by choosing your favorite date and time. You can plot the time schedule by simply clicking the (plus) button.  You can adjust this time later depending on the dates which you scheduled.'; 

$lang['exp_additionally_tagline']='Get the lowdown on Detroit’s fashion renaissance or Document daily life with two Cuban filmmakers.'; 

$lang['exp_great_summary_tagline']='Taglines are just a sentence long. Guests should immediately understand what they’ll do. Start with the main action, and then mention who they’ll be with or where they’ll be. It should be simple and straightforward.'; 

$lang['tips_for_tagline']='Tips for Tagline'; 

$lang['exp_inactive']='Inactive'; 

$lang['exp_Active']='Active'; 

$lang['exp_write_tagline']='Write a tagline'; 

$lang['exp_tagline_summary']='Clearly describe in one short,catchy sentence. Start with a verb that tells guests what they will do.'; 

$lang['exp_write_tagline_here']='Write your tagline here'; 

$lang['exp_img_err']='Image Height and Width should have 360 * 580px or Above.'; 

$lang['exp_add_photos']='Add photos for your experience '; 

$lang['exp_choose_photos_showcase']='Choose photos that showcase the location and what guests will be doing. photos must be at least 360 x 580 pixels.'; 

$lang['exp_img_must_be']='Image size must be larger than than 365 x 548'; 

$lang['video_url']='Enter video link'; 

$lang['exp_photo_video_url']='Make your canvas'; 

$lang['exp_gives_better']='A picture is worth a thousand words”. Use the images to speak about your experience louder than words. You can add the pictures as well as video clips of your Experience. Explorers love photos that highlight the features of your Experience.'; 

$lang['exp_great_summary_uncover']='If you’re a volunteer, employee, or board member of a registered nonprofit, you can create an experience that brings people closer to your work and encourages themes to become advocates for your cause. Give an overview description of what your guests will be doing on this experience. It is important guests know what they’re getting into..'; 

$lang['exp_additionally_uncover']='We ll bike to five foodie destinations to taste a variety of typical Dutch foods. Along the way, we ll discover the secret places of Amsterdam East—an up-and-coming area full of design shops. I ll lead you to surprising and beautiful eateries beloved by locals. At each spot we ll be welcomed by the owners and treated to delicious breads, cheeses, smoked mackerel, and more. We end the tour at the brewery  t IJ.'; 

$lang['descripe_location']='Describe your Location'; 

$lang['exp_great_summary_location']='Tell your guests where you’ll be taking them for this experience. Mention any places you’ll visit and hint at why they’re meaningful to you and the overall experience'; 

$lang['exp_additionally_location']='We’ll most likely go up to Kloof Corner Ridge, a superb ridge line scramble towards the upper Cabbleway. However, we could do a slightly different version of this run, depending on the weather and ability of the group. After we descend and clean up, we’ll enjoy dinner at one of my favorite restaurants.'; 

$lang['experience_details_hospitality']='What kind of hospitality you offer?'; 

$lang['exp_great_summary_hospitality']='Let your guests know if you’ll be including anything for this experience. To make your experience a memorable one, you can provide meal, drink, transportation, accommodations etc for your guest as a part of refreshment.'; 

$lang['exp_mention_what']='Mention what you will do'; 

$lang['Itwillonly_hospitality']='Snack, Paragliding equipment'; 

$lang['comfirm_what_will_provide']='Confirm what you ll provide'; 

$lang['comfirm_what_will_provide_summary']='On this page, you can ass additional details about what you are providing. For example, you can let your guests know that you accomodate vegetarians..'; 

$lang['exp_describe_in_detail']='Describe in detail what you wil  be doing with your guests. The more information you can give, the better.'; 

$lang['exp_what_you_will']='What you will do'; 

$lang['exp_mention_where']='Mention where you will be'; 

$lang['exp_name_all_the']='Name all the locations you will visit. Give guests a glimpse of why they are meaningful.'; 

$lang['exp_let_guests_know']='Let guests know exactly where you will be meeting. The exact address wont be shared with guests untill the book'; 

$lang['exp_item']='Item'; 

$lang['exp_no_items_added']='No Items added..'; 

$lang['exp_add_new_item']='Add new item'; 

$lang['exp_about_item']='About Item'; 

$lang['exp_update']='Update'; 

$lang['exp_quantity']='Quantity'; 

$lang['exp_description_about_the_item']='Description about the item what you provide'; 

$lang['exp_what_else_guest_know']='Is there anything you’d like guests to know before booking?'; 

$lang['exp_adddtionals_footnotes']='Passenger to bring: sneakers, wind jacket, long trousers, and sunglasses. The time may change depending on the weather conditions.'; 

$lang['exp_great_summary_footnotes']='Always ensure that you should be transparent to your guest. Even more explicitly describe your prerequisites to the guest to build credibility in you.'; 

$lang['experience_details_footnotes']='Add Footnotes'; 

$lang['experience_details_intro']='A Short Intro'; 

$lang['exp_great_summary_intro']='Sometimes the words we leave unspoken are the most important ones that should have been said. So don’t miss this opportunity to speak about you. Give a short biography of you.'; 

$lang['exp_additionally_intro']='I followed my passion since I was child. I loved to build and fly paper airplanes. I started to fly at the age of 16, now I m professional paragliding pilot, I participate in international competitions like Paragliding World Cup in many nation and European championships with paragliding Italian national team.'; 

$lang['guest_requirement_new']='Have any guest requirements?'; 

$lang['guest_requirement_transparent']='Be Transparent'; 

$lang['exp_description_the_req_transparent']='Always add a footnote to your guest. It helps them to make extra precautions. Add any age limits, certifications, or abilities required for your experience. Give a vivid description about your requirements to the guest which builds credibility in you.'; 

$lang['experience_details_precise']='Be Precise'; 

$lang['exp_great_summary_prices']='Make sure that you have entered a right count. Don’t forget to maintain the quality of service for each guest throughout the Experience. You don’t have to fill all of them. Experiences are meant to be social, so other travelers could join too.'; 

$lang['experience_details_price']='Fix your price'; 

$lang['exp_great_summary_price']='The price you set for your experience is up to you, and you can change it at any time. When setting your price, factor in things like the cost of any materials you need, the time you spend setting up, and the cost of food or rentals that you include for each guest. Consider calculating these expenses based on a full group of guests, as opposed to trying to calculate it for each individual guest. Make sure your price reflects the service you provide.'; 

$lang['CancellationPolicy_exp']='Choose your cancellation Policy'; 

$lang['exp_detailed_description_about_cancel']='HomestayDNN allows hosts to choose among three standardized cancellation policies (Flexible, Moderate, and Strict) that we will enforce to protect both guest and host alike. Guests may cancel and review any penalties by viewing their travel plans and then clicking ‘Cancel’ on the appropriate reservation. A host s cancellation policy can be found in the Cancellations section of their listing page. Guests will also be asked to agree to the host`s cancellation policy when they make a booking.'; 

$lang['exp_mention_anything_that_guests']='Mention anything that guests will have to bring eith them or arrange on their own, like transportation.'; 

$lang['exp_add_notes']='Add notes'; 

$lang['exp_note_to_guest']='Notes to guests'; 

$lang['exp_write_your_bio']='Write your bio'; 

$lang['exp_describe_yourself']='Describe yourself and tell guests how came to be passionate about hosting this experience.'; 

$lang['about_host']='About you'; 

$lang['Atitleandsummary2']='Mention anything that guests will have to bring eith them or arrange on their own, like transportation.'; 

$lang['exp_description_the_req']='Description the requirement Have To Submit By Guest for your experience.'; 

$lang['exp_maximum_number_ofGuests']='Maximum number of guests'; 

$lang['exp_num_of_guest_accommodate']='What is the number of guests you can accommodate?'; 

$lang['exp_fill_group_size']='Please fill group size'; 

$lang['exp_select_size']='Select size'; 

$lang['exp_price_per_guest']='Set a price per guest'; 

$lang['exp_price_experience']='The price of your experience is entirely up to you. Play with the calculator to see how much you would earn depending on the number of guests.'; 

$lang['exp_flexible']='Flexible';  ?>